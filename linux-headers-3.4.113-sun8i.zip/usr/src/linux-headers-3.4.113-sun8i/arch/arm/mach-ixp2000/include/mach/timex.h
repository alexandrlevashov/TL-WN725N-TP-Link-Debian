/*
 * arch/arm/mach-ixp2000/include/mach/timex.h
 *
 * IXP2000 architecture timex specifications
 */


/*
 * Default clock is 50MHz APB, but platform code can override this
 */
#define CLOCK_TICK_RATE	50000000


