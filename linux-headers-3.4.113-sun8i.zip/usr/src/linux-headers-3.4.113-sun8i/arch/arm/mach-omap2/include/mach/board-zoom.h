/*
 * Defines for zoom boards
 */
#include <video/omapdss.h>

#define ZOOM_NAND_CS    0

extern int __init zoom_debugboard_init(void);
extern void __init zoom_peripherals_init(void);
extern void __init zoom_display_init(void);

#define ZOOM2_HEADSET_EXTMUTE_GPIO	153
