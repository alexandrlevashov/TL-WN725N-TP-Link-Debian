/*
 * arch/arm/mach-omap2/include/mach/uncompress.h
 */

#include <plat/uncompress.h>
