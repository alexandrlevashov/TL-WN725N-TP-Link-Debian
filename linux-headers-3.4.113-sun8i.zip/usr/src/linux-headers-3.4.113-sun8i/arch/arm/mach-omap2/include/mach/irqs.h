/*
 * arch/arm/mach-omap2/include/mach/irqs.h
 */

#include <plat/irqs.h>
