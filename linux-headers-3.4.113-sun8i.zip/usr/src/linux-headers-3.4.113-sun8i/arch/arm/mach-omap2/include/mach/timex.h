/*
 * arch/arm/mach-omap2/include/mach/timex.h
 */

#include <plat/timex.h>
